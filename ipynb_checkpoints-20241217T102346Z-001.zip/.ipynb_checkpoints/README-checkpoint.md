# **Web Data Scraper and Storage Tool**

This tool scrapes structured content like headings, paragraphs, and other text data from a specified website. The scraped data is stored in a  **JSON format** .

## **Features**

1. Scrapes content (headings, paragraphs) from web pages.
2. Saves the scraped content into organized JSON files.
3. Provides support for running on a local or hosted environment.

---

## **Requirements**

### **Dependencies**

Ensure the following Python packages are installed:

* `requests`
* `beautifulsoup4`
* `python-dotenv`

To install dependencies:

```bash
pip install requests beautifulsoup4 python-dotenv
```

### **Environment Variables**

Create a `.env` file in the root directory for required environment variables.

Example:

```
# Add any API keys or configurations here
OPENAI_API_KEY="YOUR-OPENAI-API-KEY"
PINECONE_API_KEY="YOUR-PINECONE-API-KEY"

```

---

## **Setup Instructions**

1. **Install Dependencies** :

```bash
   pip install -r requirements.txt
```

1. **Set Up Environment Variables** :
   Ensure the `.env` file is properly configured.
2. **Run the Script** :
   You can execute the scraper by running the main script:

```bash
   python main.py
```

---

## **Key APIs/Functions**

### **1. `scrapeData(url)`**

* **Description** : Fetches content from the provided URL and extracts headings and paragraphs.
* **Parameters** :
* `url` (str): The web page URL to scrape.
* **Output** :
* Dictionary containing:
  * `url` (str)
  * `headings` (list of headings)
  * `paragraphs` (list of paragraphs)
* **Example** :

```python
  data = scrapeData("https://www.example.com")
  print(data)
```

### **2. `save_to_json(data, output_dir)`**

* **Description** : Saves the extracted data into a JSON file.
* **Parameters** :
* `data` (dict): Scraped data to be saved.
* `output_dir` (str): Directory path where JSON file will be stored.
* **Example** :

```python
  save_to_json(data, "./output")
```

---

## **Directory Structure**

```
project-folder/
│
├── .env                # Environment variables
├── main.py             # Main script for execution
├── utils.py            # Utility functions (scraper, saver, etc.)
├── output/             # JSON files will be stored here
├── requirements.txt    # Required dependencies
└── README.md           # Project documentation
```

---

## **Example Workflow**

1. Import the required functions:
   ```python
   from utils import scrapeData, save_to_json
   ```
2. Provide a URL and scrape the data:
   ```python
   url = "https://www.uchicago.edu/"
   scraped_data = scrapeData(url)
   ```
3. Save the scraped data into JSON:
   ```python
   save_to_json(scraped_data, "./output")
   ```

---

## **Output Example**

A sample JSON file will look like this:

```json
{
    "url": "https://www.uchicago.edu/",
    "headings": [
        "The University of Chicago",
        "Our History"
    ],
    "paragraphs": [
        "The University of Chicago is a private research university...",
        "Since its founding in 1890..."
    ]
}
```

---

Feel free to ask if you need additional details or enhancements! 🚀
